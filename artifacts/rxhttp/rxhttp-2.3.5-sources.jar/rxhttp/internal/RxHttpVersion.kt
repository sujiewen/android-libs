@file:JvmName("RxHttpVersion")

package rxhttp.internal

/**
 * User: ljx
 * Date: 2020/5/17
 * Time: 18:29
 */
const val userAgent = "rxhttp/2.3.5"